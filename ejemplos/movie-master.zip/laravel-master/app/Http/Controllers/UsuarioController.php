<?php

namespace Cinema\Http\Controllers;

use Illuminate\Http\Request;
use Cinema\Http\Requests\UserCreateRequest;
use Cinema\Http\Requests\UserUpdateRequest;
use Cinema\User;
use Redirect;
use Session;

class UsuarioController extends Controller
{
    public function index(){
    	//$users = User::All();
        $users = User::paginate(2);
    	return view('usuario.index',compact('users'));
    }

    public function create(){
    	return view('usuario.create');
    }

    public function show($id){

    }

    public function store(UserCreateRequest $request){
    	User::create([
    		'name' => $request['name'],
    		'email' => $request['email'],
    		'password' => $request['password']
    	]);
    	return redirect('/usuario')->with('message','store');
    }

    public function edit($id){
    	$user = User::find($id);
    	return view('usuario.edit',['user'=>$user]);
    }

    public function update($id,UserUpdateRequest $request){
    	$user = User::find($id);
    	$user->fill($request->all());
    	$user->save();
    	Session::flash('message','Usuario Editado Correctamente');
    	return Redirect::to('/usuario');
    }

    public function destroy($id){
    	User::destroy($id);
    	Session::flash('message','Usuario eliminado correctamente');
    	return Redirect::to('/usuario');
    }	
}