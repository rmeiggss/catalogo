<?php

namespace Cinema\Http\Controllers;

use Illuminate\Http\Request;

class MovieController extends Controller
{
    public function index(){
    	return "Estoy en el index";
    }

    public function create(){
    	return 'Estoy en el create formulario para crear';
    }

    public function edit(){

    }

    public function update(){

    }

    public function store(){

    }

    public function show(){

    }
}
