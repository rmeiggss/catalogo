@extends('layouts/admin')

<?php $message=Session::get('message');?>

@if(Session::has('message'))

	<div class="alert alert-success" role="alert">
	  <h4 class="alert-heading">Well done!</h4>
	  <p>{{ Session::get('message') }}</p>
	</div>

@endif

@section('content')

	<table class="table">
		<thead>
			<th>Nombre</th>
			<th>Correo</th>
			<th>Operacion</th>
		</thead>
		@foreach($users as $user)
		<tbody>
			<td>{{ $user->name }}</td>
			<td>{{ $user->email }}</td>
			<td>
				{{ link_to_route('usuario.edit', $title = 'Editar', $parameters = $user->id, $attributes = ['class'=>'btn btn-primary']) }}

			</td>
		</tbody>
		@endforeach
	</table>
	{!! $users->render() !!}
@stop