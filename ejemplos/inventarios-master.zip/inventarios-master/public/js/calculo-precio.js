/*
function calcularPrecio()
{
    var costo = $('#cost').val();
    var iva = $('#iva').val();
    var precio = costo * 1.4 * ((iva/100) + 1);

    $('#price').val(precio);
}

$('#cost').on('change', calcularPrecio);
$('#iva').on('change', calcularPrecio);
*/