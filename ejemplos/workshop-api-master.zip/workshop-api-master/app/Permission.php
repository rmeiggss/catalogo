<?php

namespace App;

//use Illuminate\Database\Eloquent\Model;
use Laratrust\LaratrustPermission;

class Permission extends LaratrustPermission
{
    //
}
