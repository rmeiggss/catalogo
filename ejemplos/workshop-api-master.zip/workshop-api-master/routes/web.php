<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function() {
    return view('welcome');
});

Route::get('/saveTweets', function() {
    return view('save-tweets');
});

Route::post('/tw/savetweet', 'TwitterController@saveTweet')->name('save.tweet');

Route::get('/', function () {
    //md5('cadena');
    echo Hash::make('edteam');
    echo "<br />";
    echo bcrypt('secret');
    echo "<br />";
    $cadena = 'laravel';

    //Encripta
    echo Crypt::encrypt($cadena);
    echo "<br />";
    //Desencripta
    //use Illuminate\Support\Facades\Crypt;
    //echo Crypt::decrypt($cadena);
    echo "<br />";
    echo md5('yesi');

    //return view('welcome');
});
