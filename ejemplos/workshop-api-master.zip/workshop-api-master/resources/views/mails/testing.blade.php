<!DOCTYPE html>
<html>
<head>
    <title>Envio de correos</title>
</head>
<body>

    <h1>{{$titulo}}</h1>
    <h4>{{$mensaje}}</h4>

</body>
</html>
