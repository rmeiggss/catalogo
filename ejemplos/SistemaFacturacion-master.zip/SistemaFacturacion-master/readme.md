## Laravel PHP Framework

Sistema de facturacion realizado con laravel 5
