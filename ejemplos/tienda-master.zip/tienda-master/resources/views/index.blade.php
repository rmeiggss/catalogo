@extends('layouts.principal')

@section('title', 'Page Title')

@section('content')

	<h3><a href="">Cursos</a></h3>
	<p>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
	</p>
	<br/>
	<ul class="list-unstyled video-list-thumbs row">
		<li class="col-lg-3 col-sm-4 col-xs-6">
			<a href="#" title="Claudio Bravo, antes su debut con el Barça en la Liga">
				<img src="http://i.ytimg.com/vi/ZKOtE9DOwGE/mqdefault.jpg" alt="Barca" class="img-responsive" height="130px" />
				<h2>Claudio Bravo, antes su debut con el Barça en la Liga</h2>
				<span class="play-button"></span>
				<span class="duration">03:15</span>
			</a>
			<h3><a href="cursos.html">Ingles para maestristas</a></h3>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.				
		</li>
		<li class="col-lg-3 col-sm-4 col-xs-6">
			<a href="#" title="Claudio Bravo, antes su debut con el Barça en la Liga">
				<img src="http://i.ytimg.com/vi/ZKOtE9DOwGE/mqdefault.jpg" alt="Barca" class="img-responsive" height="130px" />
				<h2>Claudio Bravo, antes su debut con el Barça en la Liga</h2>
				<span class="play-button"></span>
				<span class="duration">03:15</span>
			</a>
			<h3><a href="cursos.html">Ingles para maestristas</a></h3>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.								
		</li>
		<li class="col-lg-3 col-sm-4 col-xs-6">
			<a href="#" title="Claudio Bravo, antes su debut con el Barça en la Liga">
				<img src="http://i.ytimg.com/vi/ZKOtE9DOwGE/mqdefault.jpg" alt="Barca" class="img-responsive" height="130px" />
				<h2>Claudio Bravo, antes su debut con el Barça en la Liga</h2>
				<span class="play-button"></span>
				<span class="duration">03:15</span>
			</a>
			<h3><a href="cursos.html">Ingles para maestristas</a></h3>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.								
		</li>
		<li class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
			<a href="#" title="Claudio Bravo, antes su debut con el Barça en la Liga">
				<img src="http://i.ytimg.com/vi/ZKOtE9DOwGE/mqdefault.jpg" alt="Barca" class="img-responsive" height="130px" />
				<h2>Claudio Bravo, antes su debut con el Barça en la Liga</h2>
				<span class="play-button"></span>
				<span class="duration">03:15</span>
			</a>
			<h3><a href="cursos.html">Ingles para maestristas</a></h3>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.								
		</li> 
	</ul>	
@stop