jQuery(function($){

  $(document).on('ready', function(){

    $("#btnFiltrar").on('click', function(){
      $("#acordion").toggle("slow");
    });

  }); //on ready

}); //jQuery