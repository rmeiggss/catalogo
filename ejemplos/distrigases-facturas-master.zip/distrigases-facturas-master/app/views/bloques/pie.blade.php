<footer class="well well-sm">
    <span class="text text-info">
        &copy;2014 danielromeroauk@gmail.com
    </span>
</footer>