@extends('cotizaciones.pdf')

@section('encabezado')

  <div style="border: solid 1px red;">
    Aqu&iacute; ir&aacute; el encabezado.
  </div>

@stop

@section('pie')

  <div style="border: solid 1px red;">
    Aqu&iacute; ir&aacute; el pie.
  </div>

@stop