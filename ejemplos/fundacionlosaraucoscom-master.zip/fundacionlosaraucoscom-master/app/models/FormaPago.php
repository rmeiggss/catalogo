<?php

class FormaPago extends Eloquent
{
    protected $table = 'formaspago';
}