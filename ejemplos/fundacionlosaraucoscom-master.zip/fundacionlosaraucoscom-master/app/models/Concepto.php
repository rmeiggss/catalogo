<?php

class Concepto extends Eloquent
{
    protected $table = 'conceptos';
}