<?php

class FechaCorte extends Eloquent
{
    protected $table = 'fechadecorte';
}