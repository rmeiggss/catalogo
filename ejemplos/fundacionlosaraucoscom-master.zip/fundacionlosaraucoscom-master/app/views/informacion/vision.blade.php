@extends('layouts.master')

@section('title')
  Objetivos
@stop

@section('contenido')

  <section class="container">
    <h1>Nuestra visión</h1>
    <p>Ser líder en la búsqueda del Desarrollo Económico y Bienestar Social de las Trabajadores y Trabajadoras Contratistas y Subcontratista que laboran o han laborado en el complejo de caño limón y caricare en el Departamento de Arauca, que redunde en la construcción de la Arauca pos petrolera, a través de la colocación de créditos para proyectos productivos y vivienda, aplicando estrategias novedosas que permitan realizar una recuperación efectiva de cartera.</p>
  </section>

@stop