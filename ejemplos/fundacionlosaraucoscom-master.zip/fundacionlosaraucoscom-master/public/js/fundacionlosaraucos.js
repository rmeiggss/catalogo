$(document).on('ready', function(){

    $('#carousel').carousel();
    $('article').addClass('animated fadeInLeftBig');

});