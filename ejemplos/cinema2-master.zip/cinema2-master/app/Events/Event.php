<?php

namespace cinema\Events;

abstract class Event
{
    //
}
