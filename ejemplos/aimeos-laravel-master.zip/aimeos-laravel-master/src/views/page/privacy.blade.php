@extends('shop::base')

@section('aimeos_body')
 Privacy policy page
@stop
