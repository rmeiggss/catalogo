<?php
require 'vendor/autoload.php';

// Funcion para conectarnos a la base de datos
// Modificar las 4 primeras variables para conectarse
function connect()
{
    $nombreServidor = 'localhost';
    $nombreUsuario = 'root';
    $contraseña = '';
    $nombreBaseDeDatos = 'SendGrid';

    $connect = new mysqli(
        $nombreServidor,
        $nombreUsuario,
        $contraseña,
        $nombreBaseDeDatos
    );

    // Check connection
    if ($connect->connect_error) {
        die('Connection failed: ' . $connect->connect_error);
    }

    mysqli_set_charset($connect, 'utf8');

    return $connect;
}

// Funcion para enviar correo, requiere 1 parametro
// 1. Contenido (plantilla html)
function sendMail($content)
{
    // Reemplazar el string SG... por la clave api de su cuenta SendGrid
    $apiKey =
        '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';
    // Objeto de la clase Mail de SendGrid
    $email = new \SendGrid\Mail\Mail();
    // Remitente
    $email->setFrom('ceps.fiee.uni@gmail.com', 'FIEE Proyección Social');
    // Asunto
    $email->setSubject('Cursos FIEE');
    // Funcion para jalar la información de la base de datos
    // Descomentar para activar el envio masivo
    // $data = getData();
    // for ($i = 0; $i <= sizeof($data) - 1; $i++) {
    //     $email->addTo($data[$i]['Email'], $data[$i]['NombreCompleto']);
    // }
    // Email objetivo (si se desea enviar a un solo correo)
    // Comentar si desea activar el envio masivo
    $email->addTo('edward.figueroa.ing@gmail.com', 'Nombre del usuario');
    // Contenido html
    $email->addContent('text/html', $content);
    $sendgrid = new \SendGrid($apiKey);
    try {
        $response = $sendgrid->send($email);
        print $response->statusCode() . "\n";
        print_r($response->headers());
        print $response->body() . "\n";
    } catch (Exception $e) {
        echo 'Caught exception: ' . $e->getMessage() . "\n";
    }
}

// Funcion para jalar los nombres y email de los usuarios de la base de datos
function getData()
{
    // SQL query para jalar todos los emails que cada usuario tiene
    $query = "SELECT *
              FROM Cliente AS Cli
              INNER JOIN Correo AS C
              ON Cli.ID_Cliente = C.ID_Cliente";

    // Si hay una respuesta exitosa
    if ($response = mysqli_query(connect(), $query)) {
        $nFila = 0;
        while ($row = mysqli_fetch_assoc($response)) {
            $result[$nFila]['NombreCompleto'] =
                $row['Nombres'] . $row['Apellidos'];
            $result[$nFila]['Email'] = $row['Email'];
            $nFila++;
        }
        return $result;
    } else {
        http_response_code(404);
    }
}

// Funcion para obtener la plantilla del correo
function getLayout()
{
    $curl = curl_init();

    curl_setopt_array($curl, array(
        // Reemplazar el id (.../designs/ID) por el id de su plantilla de SendGrid
        CURLOPT_URL => 'https://api.sendgrid.com/v3/designs/cfb218de-01a2-4efe-8c77-066e5b22a8c3',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_POSTFIELDS => '{}',
        CURLOPT_HTTPHEADER => array(
            // Reemplazar el string SG... por la clave api de su cuenta SendGrid
            'Authorization: Bearer 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'
        )
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo 'cURL Error #:' . $err;
    } else {
        // Retorna el contenido html de la plantilla
        return json_decode($response, true)['html_content'];
    }
}

sendMail(getLayout());
?>
